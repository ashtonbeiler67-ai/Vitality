@echo off
echo Building Vitality.exe (requires Node.js from nodejs.org)...
call npm install
call npm run dist
if errorlevel 1 (echo. & echo BUILD FAILED - read the errors above. & pause & exit /b 1)
echo.
echo Done. Your app is dist\Vitality.exe
pause
