@echo off
echo Building Vitality.exe (requires Node.js from nodejs.org)...
call npm install
call npm run dist
echo.
echo Done. Your app is in the "dist" folder: Vitality.exe
pause
