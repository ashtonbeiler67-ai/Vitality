VITALITY - build the Windows .exe
1. Install Node.js (nodejs.org) if you don't have it.
2. Double-click build-exe.bat (takes a few minutes the first time).
3. Find dist\Vitality.exe. It is a single portable file; double-click to run.
To test without building: npm install, then npm start.
Your data is stored on your computer only.
