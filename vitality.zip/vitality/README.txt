VITALITY
Desktop app: double-click build-exe.bat, then run dist\Vitality.exe (needs Node.js).
Accounts, sync and AI import: see server\README.txt. Start the server first, then sign in from the app.
