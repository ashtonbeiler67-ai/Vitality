// Vitality server. Zero dependencies; needs Node 22.13+ (uses built-in node:sqlite).
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');
const PORT = process.env.PORT || 8787;
const db = new DatabaseSync(process.env.DB_PATH || path.join(__dirname, 'vitality.db'));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT, salt TEXT NOT NULL, hash TEXT NOT NULL, data TEXT DEFAULT '', created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created INTEGER NOT NULL);`);
const get = (s, ...a) => db.prepare(s).get(...a), all = (s, ...a) => db.prepare(s).all(...a), run = (s, ...a) => db.prepare(s).run(...a);
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex'); // passwords are never stored or returned
const session = id => { const t = crypto.randomBytes(32).toString('hex'); run('INSERT INTO sessions VALUES(?,?,?)', t, id, Date.now()); return t; };
const fails = {}, blocked = k => (fails[k] = (fails[k] || []).filter(t => Date.now() - t < 9e5)).length >= 10;
const send = (res, c, o) => { res.writeHead(c, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization,Content-Type,X-Admin-Key', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS' }); res.end(JSON.stringify(o)); };
const body = req => new Promise((ok, no) => { let b = ''; req.on('data', c => { b += c; if (b.length > 3e6) { no(new Error('Too large')); req.destroy(); } }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch { no(new Error('Bad JSON')); } }); });

async function ai(prompt) {
  if (!process.env.ANTHROPIC_API_KEY) throw new Error('AI is not configured. Set ANTHROPIC_API_KEY on the server.');
  const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: process.env.AI_MODEL || 'claude-haiku-4-5-20251001', max_tokens: 2000, messages: [{ role: 'user', content: prompt }] }) });
  const j = await r.json(); if (!r.ok) throw new Error(j.error?.message || 'AI request failed');
  const t = j.content[0].text; return JSON.parse(t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1));
}
const PRIVATE = /^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.|\[?::1)/i;
async function importRecipe(url) {
  const u = new URL(url); if (!/^https?:$/.test(u.protocol) || PRIVATE.test(u.hostname)) throw new Error('That link is not allowed.');
  const r = await fetch(u, { headers: { 'User-Agent': 'Mozilla/5.0 VitalityBot' }, signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error('Could not open that page (' + r.status + ').');
  const html = (await r.text()).slice(0, 1.5e6);
  const image = (html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)/i) || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image/i) || [])[1] || '';
  const ld = [...html.matchAll(/<script[^>]+ld\+json[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(x => /"Recipe"/.test(x)).join('\n').slice(0, 8000);
  const text = html.replace(/<(script|style|nav|footer|header)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 12000);
  const out = await ai(`Extract the recipe from this web page. Return ONLY JSON: {"name":string,"servings":number,"ingredients":[one string per ingredient, quantity and unit first, e.g. "200 g chicken breast" or "2 tbsp olive oil"],"instructions":"clear numbered steps as plain text, one per line","names":[3 short catchy alternative names]}.\n\nSTRUCTURED DATA:\n${ld}\n\nPAGE TEXT:\n${text}`);
  return { ...out, image: image ? new URL(image, u).href : '' };
}

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x');
    if (req.method === 'OPTIONS') return send(res, 204, {});
    if (!u.pathname.startsWith('/api/')) { const f = path.join(__dirname, 'public', 'index.html'); if (!fs.existsSync(f)) return send(res, 404, { error: 'No client found' }); res.writeHead(200, { 'Content-Type': 'text/html' }); return res.end(fs.readFileSync(f)); }
    const b = ['POST', 'PUT'].includes(req.method) ? await body(req) : {}, p = u.pathname.slice(5);
    const ip = req.socket.remoteAddress, email = String(b.email || '').trim().toLowerCase();
    if (p === 'register' && req.method === 'POST') {
      if (!/^\S+@\S+\.\S+$/.test(email) || String(b.password || '').length < 8) return send(res, 400, { error: 'Enter a valid email and a password of at least 8 characters.' });
      if (get('SELECT id FROM users WHERE email=?', email)) return send(res, 409, { error: 'That email already has an account.' });
      const salt = crypto.randomBytes(16).toString('hex'), r = run('INSERT INTO users(email,name,salt,hash) VALUES(?,?,?,?)', email, b.name || '', salt, hashPw(b.password, salt));
      const id = Number(r.lastInsertRowid);
      if (process.env.NOTIFY_WEBHOOK) fetch(process.env.NOTIFY_WEBHOOK, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text: `New Vitality account: ${email} (${b.name || 'no name'})`, content: `New Vitality account: ${email} (${b.name || 'no name'})` }) }).catch(() => {});
      return send(res, 200, { token: session(id), user: { email, name: b.name || '' } });
    }
    if (p === 'login' && req.method === 'POST') {
      if (blocked(ip) || blocked(email)) return send(res, 429, { error: 'Too many attempts. Try again in 15 minutes.' });
      const u2 = get('SELECT * FROM users WHERE email=?', email);
      const ok = u2 && crypto.timingSafeEqual(Buffer.from(hashPw(String(b.password || ''), u2.salt), 'hex'), Buffer.from(u2.hash, 'hex'));
      if (!ok) { fails[ip] = [...(fails[ip] || []), Date.now()]; fails[email] = [...(fails[email] || []), Date.now()]; return send(res, 401, { error: 'Wrong email or password.' }); }
      return send(res, 200, { token: session(u2.id), user: { email: u2.email, name: u2.name } });
    }
    if (p === 'admin/users') { // owner-only: list accounts (never passwords)
      if (!process.env.ADMIN_KEY || req.headers['x-admin-key'] !== process.env.ADMIN_KEY) return send(res, 403, { error: 'Forbidden' });
      return send(res, 200, { users: all('SELECT id,email,name,created FROM users ORDER BY id') });
    }
    const tok = (req.headers.authorization || '').replace('Bearer ', ''), s = tok && get('SELECT user_id FROM sessions WHERE token=? AND created>?', tok, Date.now() - 30 * 864e5);
    const user = s && get('SELECT * FROM users WHERE id=?', s.user_id);
    if (!user) return send(res, 401, { error: 'Unauthorized. Please sign in again.' });
    if (p === 'data' && req.method === 'GET') return send(res, 200, { data: user.data, user: { email: user.email, name: user.name } });
    if (p === 'data' && req.method === 'PUT') { run('UPDATE users SET data=? WHERE id=?', String(b.data || ''), user.id); return send(res, 200, { ok: true }); }
    if (p === 'logout') { run('DELETE FROM sessions WHERE token=?', tok); return send(res, 200, { ok: true }); }
    if (p === 'account' && req.method === 'DELETE') { run('DELETE FROM sessions WHERE user_id=?', user.id); run('DELETE FROM users WHERE id=?', user.id); return send(res, 200, { ok: true }); }
    if (p === 'import-recipe' && req.method === 'POST') return send(res, 200, await importRecipe(String(b.url || '')));
    if (p === 'names' && req.method === 'POST') return send(res, 200, await ai(`Suggest 5 short, appealing recipe names. Return ONLY JSON {"names":[...]}.\nCurrent name: ${b.name || 'none'}\nIngredients:\n${String(b.ingredients || '').slice(0, 2000)}`));
    send(res, 404, { error: 'Not found' });
  } catch (e) { send(res, 500, { error: e.message }); }
}).listen(PORT, () => console.log('Vitality server running on port ' + PORT));
