VITALITY SERVER (accounts, sync, AI recipe import)
Needs Node 22.13 or newer. No npm install required.

RUN LOCALLY
  cd server
  set ANTHROPIC_API_KEY=your-key    (Mac/Linux: export ...)   enables recipe import
  set ADMIN_KEY=pick-a-long-secret                            lets you list accounts
  node server.js
  Open http://localhost:8787 in a browser, or enter that address as the Server URL in the .exe.

SIGN IN FROM ANYWHERE
  Deploy this "server" folder to a Node host (Render, Railway, Fly.io):
    start command: node server.js
    env vars: ANTHROPIC_API_KEY, ADMIN_KEY, DB_PATH (a path on a persistent disk, e.g. /data/vitality.db)
  The host gives you an https URL. Open it in any browser, or enter it as the Server URL in the .exe.

SEE WHO SIGNED UP
  GET https://YOUR-URL/api/admin/users   with header  X-Admin-Key: <your ADMIN_KEY>
  Or set NOTIFY_WEBHOOK to a Discord/Slack webhook URL to get a message for every new account.
  Passwords are stored only as salted scrypt hashes, so nobody (including you) can read them.
